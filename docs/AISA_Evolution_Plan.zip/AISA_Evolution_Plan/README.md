# AISA Evolution Plan — revisão 2

Pacote de implementação para Claude Code · 2026-09-21.

**Objetivo:** evoluir AISA RT Fix com memória persistente e recuperação entre sessões, preservando metodologia, Shared Understanding (SU), Coverage e experiência do operador. Simplificar apenas depois de provar continuidade em pilotos.

Este pacote contém especificações e critérios de aceitação. Não contém a implementação nem resultados de testes do produto. A implementação começa por confirmar o baseline; não se declara antecipadamente que o projeto passa os testes.

## Como utilizar

1. Disponibilizar ao Claude Code o projeto alvo `aisa-rt-fix(1).zip` e o doador `ai-solution-architect-main 2(2).zip` (ou checkouts correspondentes).
2. Extrair este ZIP para uma pasta de referência. Não sobrepor o doador ao alvo.
3. Abrir o Claude Code no projeto alvo e fornecer [CLAUDE_CODE_PROMPT.md](CLAUDE_CODE_PROMPT.md).
4. Executar P0–P10 por ordem, com checkpoint no final de cada fase. P11 é experiência opcional e fica fora da conclusão obrigatória.

Não é necessário o plano anterior. Esta revisão substitui-o integralmente.

## Ficheiros e ordem de leitura

- [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md): plano completo, sequência, entregáveis e checkpoints.
- [contracts/AUTHORITY_AND_KNOWLEDGE.md](contracts/AUTHORITY_AND_KNOWLEDGE.md): autoridade por campo, estados, relações e coerência.
- [contracts/WRITES_AND_RECOVERY.md](contracts/WRITES_AND_RECOVERY.md): concorrência, publicação, falhas e bootstrap.
- [contracts/MIGRATION_AND_COVERAGE.md](contracts/MIGRATION_AND_COVERAGE.md): migração, fontes e atualidade das revisões.
- [validation/ACCEPTANCE.md](validation/ACCEPTANCE.md): protocolo de validação, oráculos e casos adversariais.
- [validation/cases.json](validation/cases.json): inventário dos casos a implementar; não são testes executáveis.
- [templates/PHASE_REPORT.md](templates/PHASE_REPORT.md): modelo de evidência e decisão GO/NO-GO.
- [templates/PILOT_ORACLE.json](templates/PILOT_ORACLE.json): estrutura vazia para referência independente de piloto.
- [CHANGELOG.md](CHANGELOG.md): tratamento dos achados da revisão e correspondência com fases anteriores.
- `SOURCE_MANIFEST.json`: hashes dos três ZIPs analisados; não afirma equivalência com outros checkouts.
- `SHA256SUMS.txt`: integridade dos ficheiros deste pacote, exceto o próprio manifesto de hashes.

## Regras de interpretação

O plano define a sequência; os contratos definem comportamento; a aceitação define a prova. Todos são normativos. Divergência entre eles bloqueia a fase afetada até ser corrigida, sem escolher silenciosamente a regra mais fácil. As regras metodológicas existentes permanecem válidas salvo a alteração explícita e limitada descrita neste pacote. Instruções do utilizador e restrições de acesso continuam a prevalecer.

O alvo mantém Python quando coerente com o kernel. Não adicionar Node, serviços, uma base de dados, um gestor de tarefas persistente ou um novo comando por cada função interna. Reutilizar ferramentas existentes e adicionar apenas o necessário.
