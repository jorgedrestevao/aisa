# P<n> — <nome>

Estado: NOT_STARTED | IN_PROGRESS | GO | NO-GO

## Identidade e precondições
- Data/ambiente/runtime:
- Commit/hash de entrada e saída:
- GO anterior e evidência:
- Contratos/casos aplicáveis:

## Nota pré-alteração
- Problema e hipótese verificável:
- Autoridades, leitores e escritores afetados:
- Comportamento esperado e risco:
- Recuperação/reversão:

## Alterações realizadas
- Ficheiros e razão:
- Comportamentos adicionados/alterados:
- ADRs/mapeamentos:
- Alterações intencionais de testes e garantia substituta:

## Verificação
| Runner/comando exato | Ambiente | Collected | Passed | Failed | Skipped | Xfail/Xpass | Errors | Duração | Log |
|---|---|---|---|---|---|---|---|---|---|
| A preencher após execução | | | | | | | | | |

- Casos de aceitação → testes/cenários/evidência:
- Testes não executados e razão:
- Falhas baseline reproduzidas vs regressões novas:
- Falhas injetadas, snapshots e recuperação:
- Pilotos/oráculos e sessões reais quando aplicável:

## Resultado e limitações
- Observado vs esperado:
- Âmbitos bloqueados:
- Limitações e impacto material:
- Métricas comparáveis: stores, hooks, artefactos obrigatórios, comandos, LOC, pacote, contexto, latência/tokens quando observados:
- GO/NO-GO e justificação por critério:
- Próxima ação concreta:

Não marcar GO com campos de evidência por preencher. N/A requer justificação. Anexar outputs; esta tabela não substitui logs.
