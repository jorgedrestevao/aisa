# AISA RT Fix — plano corrigido de implementação

Revisão 2 · 2026-09-21 · execução em Claude Code.

**Estado:** especificação revista para iniciar P0; habilitação de implementação funcional condicionada ao GO de P1. Não é uma certificação de software implementado.

## 1. Resultado pretendido e limites

Preservar Discovery, orientação do operador, Shared Understanding, Unknowns, Findings, contradições, pressupostos, Coverage, Frame → Options → Decision, Blueprint e Render. Acrescentar relações persistentes e recuperação fiel entre sessões. Reduzir mecanismos redundantes só após evidência real.

O alvo é AISA RT Fix. AI Solution Architect é doador de conceitos e testes, não de UX nem de regras metodológicas. A versão identificada neste pacote é a dos ZIPs em `SOURCE_MANIFEST.json`; nomes de ficheiros não identificam commits. P0 regista o commit se existir, sem o inventar.

O grafo não prova verdade nem transforma inferência em facto. Memória fiel não prova extração correta. Coverage avalia revisão/preservação segundo o seu contrato, não percentagem de nós preenchidos.

## 2. Evidência de partida

Confirmado por inspeção dos anexos:

- Coverage vive em `library/kernel/tools/coverage.py` e `library/kernel/coverage-contract.md`; não existe `shared-coverage.py` no alvo analisado.
- O contrato calcula atualidade a partir de fontes e fingerprints semânticos; SU/decisões não são ignoradas por serem entradas `informative`.
- `library/kernel/states.md` define Confirmed, Assumed, Unknown, Conflicted e Risky; transições preservam linhas antigas, `was <id>` e `resolved →`.
- `.claude/skills/aisa-answer/SKILL.md` preserva resposta literal, separa facto de adequação arquitetural e calcula Coverage sem escrever flags. A revalidação de dependências existente usa referências/texto.
- `.claude/hooks/on-su-change.py` é atualização assíncrona do dashboard para Write/Edit; não é um mecanismo transacional e não observa automaticamente escritas de subprocessos.
- O doador tem `lib/pkg/{schema,storage,checks,query,mutations,context,bootstrap}.mjs` e `lib/ops/projection.mjs`. O storage inclui lock e deteção de versões incoerentes; isto não fornece atomicidade entre todos os artefactos AISA.

Não foi executada a regressão completa na preparação deste pacote. O valor histórico de 1303 testes não é baseline atual. Capacidades de Discovery e continuidade devem ser medidas em P0/P8, não tratadas como qualidade já demonstrada.

## 3. Decisões de arquitetura

1. Preservar autoridades existentes: SU para afirmações e estados epistemológicos; respostas literais em answers; decisões em decisions; fase em `_state.json`.
2. O grafo detém identidade de fontes/versionamento e relações adicionais que ainda não tenham autoridade existente. Campos espelhados identificam a origem e não admitem edição independente.
3. Uma operação de domínio coordena escritas relacionadas. Contexto e gates não consomem snapshots parciais. Diário técnico de recuperação não é conhecimento nem uma fila de trabalho.
4. Coverage e gates continuam calculados. O grafo não pode declarar uma revisão válida nem fechar uma escolha estrutural por existência de uma capacidade técnica.
5. Migrar projetos antigos sem reinterpretar silenciosamente história ou promover conhecimento.
6. Bootstrap obrigatório em caminhos reais; deteção de ausência, corrupção e deriva são distintas.
7. Provar uma operação completa entre sessões cedo; provar pilotos antes dos cortes.

P1 detalha o mapeamento de implementação de acordo com os contratos anexos. Não reabre estas decisões por conveniência de porte. Incompatibilidade real com comportamento intencional do alvo exige ADR e, quando muda produto, decisão humana específica.

## 4. Política de capacidades

| Capacidade | Decisão |
|---|---|
| Discovery, Capture e orientação de Unknowns | Preservar; acrescentar persistência |
| SU e regras de evidência | Preservar; explicitar mapeamento no grafo |
| Findings | Preservar identidade e ações; mapear representação real em P1 |
| Coverage e gates | Preservar semântica; adaptar dependências materiais |
| Frame, Options, Decide, Premortem, Simulation | Preservar comportamento e encadeamento |
| Synthesis, Blueprint, Render e aprovações | Preservar contratos e histórico |
| Graph, checks e bootstrap | Portar conceitos; testar contra contratos AISA |
| Status, orientação e próxima ação | Integrar sob comandos existentes; projeções calculadas |
| `/next` | Só adicionar se P7 provar benefício não coberto pela UX existente |
| Diários e `/retro` | Auditar e tornar opcionais/retirar apenas depois de P8 |
| Anti-patterns e constraints estáticas | Preservar; impedir fuga de dados de engagements |
| Story, council-log e dashboard | Auditar unicidade; manter auditabilidade e visualizações úteis |
| Hooks | Consolidar só com equivalência demonstrada em todos os caminhos |
| Council/lenses | Preservar até experiência opcional P11 |
| Campanhas e outputs históricos | Arquivar com manifesto, referências e testes preservados |

## 5. Sequência vinculativa

Cada fase depende do GO da anterior. P11 depende de P10 e pode ser adiada sem impedir conclusão.

| Fase | Entrega principal | Condição de saída |
|---|---|---|
| P0 | Baseline reproduzível | Runners, ambiente, entradas e falhas conhecidos |
| P1 | Contratos ligados ao código e oráculos | Autoridades/escritores mapeados; zero decisão estrutural por resolver |
| P2 | Storage e protocolo de recuperação | Falhas/concorrência não produzem sucesso falso |
| P3 | Bootstrap técnico universal | Contexto verificado antes da operação, incluindo subprocessos |
| P4 | Operação completa Capture/answer entre sessões | Conhecimento e bloqueio recuperados sem conversa anterior |
| P5 | Migração de projetos existentes | Dry-run, idempotência, reversão e história preservados |
| P6 | Integração completa SU/grafo/Coverage | Atualidade e dependências corretas, estados sem divergência |
| P7 | UX e operações de todo o workflow | Status, gates e próxima ação consistentes em todos os caminhos |
| P8 | Continuidade completa e pilotos reais | Qualidade e recuperação demonstradas contra referência independente |
| P9 | Simplificação controlada | Mesmas garantias com menos obrigações redundantes |
| P10 | Hardening e distribuição | Instalação limpa, regressão e pilotos finais aceites |
| P11 | Council condicional, opcional | Só ativar se não inferior segundo critérios prévios |

## P0 — Estabelecer verdade do repositório

Sem alterações de comportamento. Inventariar kernel, packs, comandos, skills, hooks, testes, fixtures, campanhas, fontes e projetos. Ler instruções aplicáveis. Registar hashes/commit, Python e dependências, sistema operativo e comandos exatos.

Descobrir todos os runners: não pressupor que pytest cobre testes unittest executáveis, ferramentas ou scripts de aceitação. Mapear `.claude/tests`, testes das ferramentas e suites externas. Guardar IDs de testes, contagens, skips/xfails, erros, duração e logs. Timeout ou collection error nunca é aprovação.

Traçar SU, answer, capture, state, decisões, Coverage (todas as etapas), render/blueprint, resolução/reabertura, delegação/lenses, status e hooks. Medir um fluxo representativo e tamanho do contexto. Identificar entradas reais de pilotos e direitos de acesso necessários. Classificar campanhas sem mover nada ainda.

Entregas no alvo: `docs/evolution/P0-report.md`, `baseline-test-inventory.json`, `source-inventory.json`, `runtime-map.md`. O inventário de testes inclui falhas pré-existentes individualmente e reprodução.

Checkpoint: todos os modos de teste descobertos executados. GO pode ter falha pré-existente isolada e documentada que não impeça provar o trabalho posterior; baseline que não recolhe suites ou não executa mecanismos críticos é NO-GO. Não corrigir silenciosamente o baseline.

## P1 — Ligar contratos ao código e fixar referências de aceitação

Aplicar `contracts/AUTHORITY_AND_KNOWLEDGE.md`, `contracts/WRITES_AND_RECOVERY.md` e `contracts/MIGRATION_AND_COVERAGE.md` a caminhos, funções, leitores e escritores reais. Mapear todos os campos existentes e todas as entradas de mutação; documentar casos não equivalentes ao doador.

Escolher o formato concreto mínimo de storage e mecanismo de serialização/recuperação que satisfaça o contrato. Definir limites operacionais, política de lock, erros recuperáveis, revisão de snapshot e forma de validar leitores de subprocessos. Não introduzir um serviço.

Fixar representação de Findings; manter identidade, evidência, criticidade, ação e histórico onde existam. Não criar um novo enum de estados SU. Documentar a única substituição de instrução metodológica autorizada: referências persistentes podem complementar/substituir a pesquisa textual de dependentes em `aisa-answer`; não removem revalidação direcionada, não fazem rerun indiscriminado nem reescrevem decisões.

Produzir: `authority-map.md`, `writer-reader-map.md`, `integration-adr.md`, `test-map.json` e oráculos preenchidos dos pilotos. Adaptar templates anexos, com proveniência. Preparar casos pequenos de falha e projeto antigo representativo.

Checkpoint: validação documental de cobertura de todos os escritores/campos + regressão baseline. GO exige contratos operacionalizáveis, IDs de casos ligados a fases e piloto obrigatório com entrada disponível. Oráculos não podem ser meramente a saída do sistema candidato. Pendências materiais bloqueiam código funcional.

## P2 — Fundação de persistência e recuperação

Implementar grafo aditivo em Python se coerente, usando APIs internas pequenas de leitura, validação, mutação e consulta. Esquema versionado, IDs estáveis, relações tipadas, proveniência, duplicação controlada e serialização determinística.

Implementar o coordenador de operações e recuperação antes de ligar escritores de negócio. Reutilizar atomicidade/locks existentes quando suficiente. Criar injeção de falhas entre pontos de publicação. Verificar campos desconhecidos sem os apagar silenciosamente. Não interpretar um store ilegível como inexistente.

Checkpoint: casos K01–K08 e W01–W08, testes existentes de estado/persistência e regressão completa. GO: nenhuma escrita rejeitada altera a verdade; interrupção é recuperável; duas sessões não perdem atualizações; leitores não declaram sucesso sobre estado misto. Ainda não se declara continuidade de negócio.

## P3 — Bootstrap técnico universal

Integrar identidade do engagement → recuperação pendente explícita → snapshot consistente → checks → autoridades → contexto material → operação. A leitura de bootstrap não repara nem inicializa silenciosamente. Recuperação é uma ação separada e registada antes da leitura.

Cobrir comandos, skills, pedidos em linguagem natural, execuções via shell, entrada sem `/start`, troca de projeto e contexto de lenses. O verificador de textos é apenas teste estrutural auxiliar. Testes de execução devem observar snapshot/engagement lidos antes de efeitos.

Aplicar orçamento de contexto, proveniência, dependências e indicação de parcialidade. Preservar fallback para projetos genuinamente sem grafo. Grafo corrompido não autoriza fallback silencioso.

Checkpoint: B01–B07, regressão de skills/hooks e suite completa. GO apenas técnico; não afirmar que toda a experiência já preserva conhecimento.

## P4 — Primeira operação completa de negócio

Ligar Capture/Discovery, registo SU e `/answer` ao coordenador e ao grafo. Usar uma fonte com regra, Unknown e pressuposto conhecidos. Confirmar somente ao nível e com a autoridade que `states.md` permite. Não fechar escolha arquitetural por confirmação de conectividade.

Executar: captura → SU/links persistidos → resposta literal → transição append-only → verificar Coverage pelo motor → terminar sessão → nova sessão sem histórico → mesmo estado, proveniência e bloqueio/próxima ação. O caso inclui falha após uma escrita e repetição da operação recuperada.

A integração inicial respeita Coverage existente; não passa um gate se existe divergência ou recuperação pendente. Fontes repetidas não multiplicam nós. Fornecer output “o que mudou / estado / próximo passo”.

Checkpoint: L01–L05, W01–W08 ligados à operação real, testes de capture/answer/SU/Coverage e regressão completa. GO prova esta sequência delimitada, não todo o workflow.

## P5 — Migração explícita de engagements existentes

Implementar o protocolo de migração anexo. Usar projeto novo, projeto com história resolvida e projeto com ambiguidades. Dry-run primeiro; preservar bytes originais em snapshot recuperável, IDs e locators. Grafo sem conhecimento nunca conta como migração bem-sucedida de projeto avançado.

O relatório discrimina importado, projetado, ambíguo, inválido e não suportado. Não reinterpretar terceiros como owner, inferência como confirmação, nem reabrir linhas marcadas resolved. Não eliminar ferramentas de migração necessárias a utilizadores de versões antigas no cleanup final.

Checkpoint: M01–M06, regressão SU/decisions/state e suite completa. GO exige migração repetível, sem duplicação, reversão testada e zero perda material não declarada. Se ambiguidade afeta segurança de avanço, bloquear só o âmbito afetado e pedir resolução, sem declarar migração funcionalmente completa desse projeto.

## P6 — Coerência, fontes e Coverage completas

Cobrir Unknowns, Findings, Conflicted, Risky, Assumed, decisões, revalidação/expiração, mudanças de fonte e relações entre conhecimento e artefactos downstream. Respeitar `was`, `resolved`, N/A/retirada segundo semântica existente e `fact ≠ fit`.

Implementar comparação semântica por campo/ID, não equivalência formal de prosa. Campos materiais do grafo que afetam uma revisão têm representação autoritativa existente ou fingerprint de dependências consumidas, explicitamente previsto no contrato. Nunca ambos de forma independente.

Atualizar fontes de forma versionada; distinguir extração indisponível, locator quebrado e evidência contraditória. Relacionar atualização com conclusões dependentes sem as invalidar todas indiscriminadamente. Alterar contrato de Coverage só nos limites técnicos descritos; mudança de semântica de suficiência exige decisão de produto.

Checkpoint: L06–L10, C01–C08, todos os testes Coverage incluindo fases blueprint/render, e regressão completa. GO: zero divergência material tolerada; nenhum flag substitui o motor.

## P7 — Projeções e UX de todo o workflow

Integrar sob start/orient/resume/status/answer/frame/options/decide/premortem/simulate/synthesize/blueprint/render/revisit. Construir estado operacional, fila temporária e próxima ação a partir de autoridades verificadas. Gates avaliam snapshot completo, não apenas excerto de contexto.

Bloqueio explica o que falta, por que importa, evidência necessária e ação. Um Unknown não bloqueante continua visível. Não criar percentagens arbitrárias nem duplicar `/resolve`/`/advance` por existirem no doador. Preservar regras de fases e aprovação de Blueprint/Render.

Dashboard é projeção; chamada direta ao motor deve atualizar/invalidar a projeção sem depender apenas de PostToolUse. Ler uma projeção desatualizada deve indicar essa condição. Não confundir dashboard atrasado com verdade de gate.

Checkpoint: U01–U05, cobertura de cada entry point no mapa P1, testes workflow/gates/status/hooks e regressão completa. Avaliação com operador que não precise de IDs internos: próximo passo compreendido em cerca de 2 minutos, com protocolo e observação registados, não estimativa inventada.

## P8 — Ciclo completo entre sessões e pilotos reais

Executar sessões independentes para Capture/Discovery, resolução, Frame, Options, Premortem/Simulation quando aplicável, Decide, Blueprint e Render/Deliver. Usar o mesmo modelo/configuração de comparação quando disponível, registando limites de reprodutibilidade.

Pelo menos dois pilotos reais distintos se disponíveis: um operacional/tickets e um Excel com regras/cálculos e dependências. Não presumir que ficheiros mencionados noutros chats estão presentes. Se só um estiver disponível, obter o segundo para o gate completo; não substituir por demo e declarar equivalência. Pilotos não incluídos no ZIP devem ter localização e hash registados em P1.

Medir separadamente correção da extração, fidelidade da persistência e recuperação entre sessões. Referência independente bloqueia omissões de regras críticas, falsos factos e progressão indevida. Produzir representação navegável/traversável do projeto com ligações e proveniência, sem obrigar uma UI nova; não inventar arestas para tornar o grafo visualmente conectado.

Checkpoint: E01–E05 e todos os testes novos/antigos. GO obrigatório antes de simplificar. Relatórios distinguem testes de processos de testes em sessões reais Claude Code; falta destas sessões bloqueia aceitação de continuidade do agente, mesmo com teste Python verde.

## P9 — Simplificação por equivalência

Só após GO de P8. Classificar cada corte e respetiva garantia; alterar um grupo coerente de cada vez, medir e rever regressão.

- Campanhas: separar fixtures ativas, evidência de aceitação, histórica, outputs gerados e obsoletos; arquivar com hashes/destino e atualizar referências. Não destruir história.
- Diários/retro: preservar reflexão útil e conhecimento estático curado; remover mutação universal redundante; garantir isolamento entre projetos. Não copiar dados de clientes para packs universais.
- Story: tornar opcional apenas se controlos únicos estiverem preservados noutro ponto identificado.
- Council-log: manter histórico exigido por transições/revalidações; cortar apenas narrativa duplicada.
- Dashboard: manter visualizações úteis como projeções.
- Hooks: matriz invariante × entry point × proteção restante; provar bypass por shell, erro e escrita externa antes de remover defesa. Um teste não substitui enforcement em runtime.

Checkpoint: S01–S04, targeted por corte, regressão completa e repetição dos pilotos afetados (incluindo reinício). GO: qualidade não inferior, mecanismos obrigatórios/duplicados reduzidos ou todos os candidatos justificados como únicos. Não forçar cortes para cumprir uma meta de LOC.

## P10 — Hardening, pacote e conclusão

Validar ambiente limpo, caminho com espaços, setup suportado, projeto externo quando suportado, reabertura depois de atualização de versão e recuperação. Excluir caches/distribuição histórica sem remover fixtures do pacote de desenvolvimento.

Eliminar só scaffolding morto comprovado; manter migração e recuperação suportadas. Registar limites de escala medidos de contexto/grafo e compatibilidade de versões/ambientes; não prometer suporte não testado.

Entregas: `docs/evolution/FINAL-VALIDATION.md`, guia de instalação/resume/recuperação/migração, manifestos de distribuição/arquivo e changelog. Comparar baseline/final por identidade de testes, não apenas contagem; listar alterações legítimas de contrato e falhas pré-existentes restantes.

Checkpoint: ambiente limpo + regressão completa + smoke de migração/recuperação e pilotos finais suficientes para provar alterações desde P8/P9. GO só quando todos os casos obrigatórios têm evidência e nenhum bloqueio material está mascarado. Estado final não pode chamar P11 incompleta uma falha da entrega base.

## P11 — Experiência opcional de council condicional

Preservar disponibilidade de todas as lentes e chairman. Comparar council atual com encaminhamento por materialidade; não ativar automaticamente uma configuração por poupar tokens. Fixar antes critérios de não inferioridade: nenhum item crítico esperado perdido, nenhum facto indevidamente confirmado, nenhum gate indevido, nenhuma violação de evidência; comparar ruído, revisão independente, tokens/tempo.

Usar os mesmos inputs e referência, incluindo casos onde a relevância de uma lente é inicialmente pouco evidente. Ausência de avaliação de qualidade ou resultado inconclusivo mantém council atual. A adoção por defeito exige evidência do teste e decisão de produto se houver trade-off. Regressão completa após qualquer mudança de default.

## 6. Protocolo de fase e limites de autonomia

Seguir `validation/ACCEPTANCE.md`. Para cada fase: nota prévia → alteração mínima → targeted → subsystem → full regression → relatório → GO/NO-GO. Atualizar relatório durante a execução e dar progresso regular ao operador. GO não exige confirmação humana rotineira; continuar autonomamente à próxima fase.

Não apagar, saltar ou enfraquecer testes para obter verde. Alterações intencionais (p.ex. story opcional) permitem atualizar testes apenas com comportamento antigo/novo, justificação, ligação ao contrato e testes que preservem a garantia. Comparar falhas pelo ID e assinatura, não apenas pelo total.

Após duas tentativas consecutivas sem nova evidência sobre a mesma falha, interromper esse ciclo, produzir diagnóstico e classificar: bug introduzido, falha baseline, ambiente, entrada ausente ou decisão de produto. Pode continuar tarefas independentes da mesma fase; não atravessar o gate bloqueado. Não usar um número de tentativas para aceitar defeito. Pedir input apenas quando informação/acesso/decisão externa é indispensável.

O código deve ser implementado no alvo pelo Claude Code. Este pacote não autoriza publicar, enviar dados, obter permissões novas, apagar histórico ou contornar instruções de acesso.

## 7. Aceitação final resumida

Obrigatório: continuidade real entre sessões; estados/história corretos; proveniência; migração reversível; recuperação de falha sem sucesso falso; isolamento; fontes atualizadas sem sobrescrever história; Coverage determinística; gates explicáveis; projeções sem verdade concorrente; UX preservada; pilotos com referência independente; regressão rastreável; distribuição limpa. Tudo com evidência em relatório.

O operador consegue saber onde está, o que sabe, o que falta e qual o próximo passo sem inspecionar o grafo. A engenharia consegue explicar e recuperar qualquer atualização interrompida sem inventar conhecimento.
