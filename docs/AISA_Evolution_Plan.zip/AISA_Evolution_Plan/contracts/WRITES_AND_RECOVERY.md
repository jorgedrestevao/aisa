# Contrato B — Escrita, recuperação e bootstrap

## B1. Garantia operacional

Uma operação material é aceite apenas quando as autoridades e projeções obrigatórias do seu conjunto de escrita são coerentes e verificadas. Uma falha pode deixar bytes parcialmente publicados, mas nunca pode produzir uma leitura operacional de sucesso sobre esse estado. Isto é atomicidade observável pelos leitores suportados, não promessa de transação universal do sistema de ficheiros.

Unidade mínima: uma captura/normalização, resolução, revalidação ou transição de fase com todos os artefactos que altera. O coordenador não estende a unidade a todo o projeto nem reescreve fontes não relacionadas. Dashboard e relatórios visuais são reconstruíveis e podem atualizar depois; não decidem gates.

## B2. Protocolo mínimo

Implementar com componentes locais existentes quando possível. Sem serviço ou framework transacional novo.

1. Identificar engagement e operação (`operation_id` estável para retries). Canonicalizar caminhos, garantir pertença ao projeto e recusar escapes/symlinks externos não autorizados.
2. Adquirir exclusão por engagement para todos os escritores suportados. Identificar posse por token/owner, não apenas ficheiro existente. Lock abandonado não é removido por timeout cego; verificar processo/ambiente e documentar recuperação segura.
3. Ler revisão esperada e hashes das autoridades relevantes. Recusar atualização sobre base diferente, mesmo se o outro escritor já libertou lock. IDs de novos registos são atribuídos sob exclusão.
4. Calcular e validar alterações sem publicar. Inputs, outputs e precondições estão no mesmo snapshot lógico. Rejeição aqui não altera artefactos de negócio.
5. Persistir intenção técnica recuperável: ID, base, conjunto de escrita, hashes before/after e bytes necessários para recuperação, com paths relativos e versão. O marcador de operação pendente tem de ficar visível antes de qualquer publicação. Staging e marcador usam escrita durável/rename apropriados ao ambiente; documentar garantias de power-loss e testar quando afirmadas.
6. Publicar substituições individuais por temp+rename; para artefactos append-only/versionados respeitar criação exclusiva e nunca sobrescrever um vNN existente. Sequência determinada e recuperável.
7. Verificar resultados e coerência. Publicar revisão de commit e recibo idempotente na própria transação (antes de retirar pendência). Só então libertar a barreira de leitura e responder sucesso.
8. Limpar temporários de operação concluída sem remover histórico AISA, backups de migração ou recibos necessários à política de retry.

O recibo contém só ID, hash do pedido, resultado/revisão e referências, não segunda verdade de negócio. Mesmo ID com payload diferente é erro. Repetição do mesmo pedido devolve resultado já concluído; não cria nova resposta/linha. P1 define retenção e âmbito do retry, sem expirar recibos de forma que uma operação antiga silenciosamente duplique efeitos. Pode reutilizar IDs persistidos em artefactos e guardar apenas metadados mínimos adicionais.

## B3. Leitura consistente

Leitores que calculam contexto, gates, Coverage consumida operacionalmente ou projeções devem usar a mesma barreira/snapshot. Solução mínima aceitável: serializar brevemente leitura e escrita pelo mesmo lock; falhar de forma explicada em contenção. Não bloquear enquanto se chama um LLM. Uma alternativa otimista tem de verificar ausência de pendência e revisão/digests antes/depois da leitura e repetir se mudar.

Se leitura foi feita antes de um raciocínio longo, a mutação compara novamente revisão e bases; alterações entretanto recebidas exigem reavaliação, não overwrite.

Uma CLI que lê ficheiros diretamente também entra no mapa de leitores. A coordenação de tools via Bash/Python não pode depender de hooks Write/Edit. Uma documentação “executar bootstrap” não é proteção suficiente. Leitores externos arbitrários não suportados ficam explicitamente fora da garantia; mudanças que façam são detetadas antes das operações suportadas.

## B4. Recuperação

Estado pendente bloqueia mutações e gate. Mostrar razão e ação de recuperação, mantendo diagnóstico read-only possível.

Recuperação adquire exclusão, valida versão da intenção e hashes de todos os ficheiros. Se cada path corresponde exatamente a before ou after e staging está íntegro, pode completar roll-forward determinístico. Se foi escolhida reversão, repor o conjunto completo antes de reabrir leitores. Se há third-state bytes, não sobrescrever: preservar e reportar conflito para resolução. Reexecutar recuperação não altera resultado.

Distinguir: store ausente; store ilegível; formato inválido; schema não suportado; par graph/meta incoerente; operação pendente; lock ativo; fonte desatualizada; evidência não verificada. Ausência permite modo legacy; os restantes não podem ser mascarados como ausência.

Não garantir rollback para versão antiga do runtime depois de alterações novas sem protocolo de compatibilidade. Migração tem reversão própria. Definir em P1 saída e códigos de erro para cada caso; não tratar contenção temporária como corrupção.

## B5. Bootstrap e contexto

Ordem: identificar engagement → detetar necessidade de recuperação → executar recuperação autorizada por via separada quando determinística → snapshot consistente → validar autoridades/grafo → construir contexto → devolver revision/digests e limitações → iniciar operação.

Bootstrap é read-only; não cria grafo, renova timestamps, marca Unknown resolvido ou repara prosa. Inicialização/migração são operações explícitas. Projeto sem grafo funciona em modo legacy declarado e não é apresentado como migrado.

Cada entrada deve demonstrar em teste que o bootstrap correu antes dos efeitos, mesmo em chamada sem `/start`, via linguagem natural ou subprocesso. Trocar engagement invalida contexto anterior. Contexto entregue a uma lente identifica projeto/revisão e âmbito; resultados são revalidados antes do commit. Não manter lock durante deliberação.

## B6. Orçamento e conhecimento parcial

Reservar espaço para fase, bloqueios relevantes, pressupostos/contradições materiais e decisões aplicáveis. Incluir proveniência de afirmações mostradas e dependências materiais das regras. Prioridade não depende só de recência. Se não couberem, assinalar IDs/âmbitos omitidos e pedir carregamento direcionado.

Gates consultam autoridades completas; nunca inferem ausência de bloqueios de um excerto. Contexto parcial não permite declarar que não existem Unknowns/contradições. Arestas de dependência quebradas impedem conclusões dependentes. Fonte ilegível ou locator desatualizado gera aviso de verificação ausente, mesmo quando contexto restante é utilizável.

Corrupção estrutural bloqueia uso do grafo. Deriva localizada da evidência pode manter leitura histórica com avisos e impedir apenas conclusões/avanços afetados. Confirmed antigo não é silenciosamente promovido/revalidado; aplicar transição metodológica quando exigida por `states.md`.
